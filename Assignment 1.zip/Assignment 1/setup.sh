#!/bin/bash

wget http://images.cocodataset.org/zips/test2014.zip
unzip test2014.zip
wget http://images.cocodataset.org/zips/val2014.zip
unzip val2014.zip
wget http://images.cocodataset.org/zips/train2014.zip
unzip train2014.zip
wget https://cs.stanford.edu/people/karpathy/deepimagesent/caption_datasets.zip
unzip caption_datasets.zip

conda create --name clip
conda activate clip
conda install -c pytorch pytorch
conda install -c anaconda scikit-learn
pip3 install clip-by-openai
pip install --upgrade torch torchvision
conda install --yes -c pytorch pytorch=1.7.1 torchvision cudatoolkit=11.0
pip install ftfy regex tqdm