#!/bin/bash
python run_eval.py
