
from eval import *
import numpy as np

i2t_arr = np.load('probs_data.npy')
t2i_arr = np.load('t2i_probs_data_2.npy')

print(f'Evaluation metrics on Image to text {i2t(5000, sims=i2t_arr)}')
print(f'Evaluation metrics on Text to Image {t2i(5000, sims=t2i_arr.T)}')
