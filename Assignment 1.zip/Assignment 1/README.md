## Assignment 1 - Image Retrieval via Multimedia Encoding

### Setup
`setup.sh` contains all the dataset and split download commands as well as the conda environment setup details.
To setup this assignment, please run `setup.sh`. To run this setup file, do:
```
./setup.sh
```

Alternatively, if you want to setup the env or look at how the env was setup refer below commands:
```
conda create --name clip
conda activate clip
conda install -c pytorch pytorch
conda install -c anaconda scikit-learn
pip install clip-by-openai
pip install --upgrade torch torchvision
conda install --yes -c pytorch pytorch=1.7.1 torchvision cudatoolkit=11.0
pip install ftfy regex tqdm
```

### Run the experiment
The file `run_experiment.py` runs the image-to-text and text-to-image retrieval experiment using CLIP model. It creates two numpy arrays (similarity matrices) which contain logits per image for all the 25k captions and logits per caption for 5k images. Each of the array size is of size (5000, 25000). To run it please do:
```python run_experiment.py```

### Evaluation
Now that you have the similarity matrices of each task, now comes the interesting part of evaluation. To run evaluation, please do:
```./run_pred.sh```
This shell script calls `run_eval.py` which prints the five evaluation metrics for the given tasks.