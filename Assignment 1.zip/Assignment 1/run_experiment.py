import clip
import json
import numpy as np
import torch

from numpy import save
from PIL import Image

train, val, test = {}, {},{}   # Dicionaries for storing training and test data
all_captions = []
# Opening JSON file
with open('dataset_coco.json') as json_file:
    data = json.load(json_file)
    # for printing the key-value pair of nested dictionary for loop can be used
    for i in data['images']:
        if i['split'] == 'val':
          val[i['filepath']+"/"+i['filename']] = i
        elif i['split'] == 'test':
          test[i['filepath']+"/"+i['filename']] = i
          all_captions.append(i['sentences'][0]['raw'])
          all_captions.append(i['sentences'][1]['raw'])
          all_captions.append(i['sentences'][2]['raw'])
          all_captions.append(i['sentences'][3]['raw'])
          all_captions.append(i['sentences'][4]['raw'])
        else:
          train[i['filepath']+"/"+i['filename']] = i


# Output Test
with open("test_coco.json", "w") as outfile_test:
    json.dump(test, outfile_test)

device = "cuda" if torch.cuda.is_available() else "cpu"

# load model and image preprocessing
model, preprocess = clip.load("ViT-B/32", device=device, jit=False)


# label_probs = []
i2t_label_probs = np.zeros((5000, 25000))
t2i_label_probs = np.zeros((5000, 25000))
# Opening JSON file
with open('test_coco.json') as json_file:
    data = json.load(json_file)
    for i in range(5):
      text = clip.tokenize(all_captions[5000*i:5000*(i+1)]).to(device)
      # for printing the key-value pair of nested dictionary for loop can be used
      image_count = 0
      for path,v in data.items():
        print(f'Image count is {image_count} and i is {i}')
        image = Image.open(path)
        image = preprocess(image).unsqueeze(0).to(device) 
        with torch.no_grad():
          image_features = model.encode_image(image)
          text_features = model.encode_text(text) 
          logits_per_image, logits_per_text = model(image, text)
          i2t_probs = logits_per_image.softmax(dim=-1).cpu().numpy()
          t2i_probs = logits_per_text.softmax(dim=0).cpu().numpy()

        i2t_label_probs[image_count][5000*i:5000*(i+1)] = np.array(i2t_probs)
        t2i_label_probs[image_count][5000*i:5000*(i+1)] = np.array(t2i_probs).reshape([5000,])
        image_count += 1

save('probs_data.npy', i2t_label_probs)
save('t2i_probs_data_2.npy', t2i_label_probs)
print("DONE, np array saved")
